export const AppSettings = Object.freeze({
    IS_FIREBASE_ENABLED: false,
    SHOW_START_WIZARD: false,
    SUBSCRIBE: false,
    FIREBASE_CONFIG: {
        apiKey: "AIzaSyBUScqVmMGH3llog55ujVcP2M6b7NLe-lA",
		authDomain: "onesignalexample-f359b.firebaseapp.com",
		databaseURL: "https://onesignalexample-f359b.firebaseio.com",
		projectId: "onesignalexample-f359b",
		storageBucket: "onesignalexample-f359b.appspot.com",
		messagingSenderId: "692778962096"
    },
    MAP_KEY: {
        apiKey: 'AIzaSyA4-GoZzOqYTvxMe52YQZch5JaCFN6ACLg'
    }
});
